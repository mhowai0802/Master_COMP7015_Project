"""
Configuration file for API keys and secrets.

IMPORTANT:
- Do NOT commit your real API keys into git if this project is under version control.
- You can keep this file local, or add it to .gitignore.
"""


NEWSAPI_KEY = "6fe87120df0b4a259b1acce8e5f40bce"


